from flask import render_template, Blueprint, redirect, url_for, flash
import app.forms.forms as forms 
from flask_sqlalchemy import SQLAlchemy
import models.models as models

routes_bp = Blueprint('routes', __name__)

@routes_bp.route("/")
def landing_page():
    return render_template("landing_page/index.html")

@routes_bp.route("/login")
def login():
    return render_template('login/login.html')

@routes_bp.route("/registro", methods=['GET', 'POST'])
def registro():
    form = forms.registroForm()
    if form.validate_on_submit():
        usuario = models.Usuarios.query.filter_by(email = form.email.data).first()
        if usuario is None:
            try: 
                usuario = models.Usuarios(
                    nome = form.nome.data, 
                    email = form.email.data,
                    telefone = form.telefone.data,
                    data_nasc = models.datetime.strptime(form.data_nasc.data, '%Y-%m-%d'),
                    CPF = form.CPF.data
                )
                models.db.session.add(usuario)
                models.db.session.commit()
                form.nome.data = ''
                form.email.data = ''
                form.telefone.data = ''
                form.data_nasc.data = ''
                form.CPF.data = ''
                flash("Registro realizado com sucesso!", "success")
            except Exception as e:
                models.db.session.rollback()
                flash("Erro ao registrar o usuário: {e}", "danger")
        else:
            flash("Esse e-mail já está registrado.", "warning")        
    return render_template('registro/registro.html', form=form)