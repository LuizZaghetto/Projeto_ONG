# catalogo.py

def obter_catalogo():
    return [
        {
            "img": "img/dog_example01.jpeg",
            "nome": "Rex",
            "idade": "2 anos",
            "sexo": "Macho",
            "porte": "Grande",
            "descricao": "Muito dócil e brincalhão."
        },
        {
            "img": "img/dog_example02.jpeg",
            "nome": "Fido",
            "idade": "1 ano",
            "sexo": "Macho",
            "porte": "Médio",
            "descricao": "Amigável e gosta de correr."
        },
        {
            "img": "img/gato_example01.jpg",
            "nome": "Mia",
            "idade": "3 anos",
            "sexo": "Fêmea",
            "porte": "Pequeno",
            "descricao": "Independente e carinhosa."
        },
        {
            "img": "img/gato_example02.jpg",
            "nome": "Luna",
            "idade": "6 meses",
            "sexo": "Fêmea",
            "porte": "Pequeno",
            "descricao": "Brincalhona e curiosa, adora explorar."
        },
        {
            "img": "img/gato_example03.jpg",
            "nome": "Simba",
            "idade": "4 anos",
            "sexo": "Macho",
            "porte": "Médio",
            "descricao": "Calmo e gosta de ob."
        },
        {
            "img": "img/dog_example03.jpeg",
            "nome": "Bella",
            "idade": "3 anos",
            "sexo": "Fêmea",
            "porte": "Pequeno",
            "descricao": "Muito amorosa e carinhosa, ótima companhia."
        },
    ]
