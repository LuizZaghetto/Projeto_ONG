from flask import Flask, render_template, jsonify, abort, flash, Blueprint
from app.controllers.routes import routes_bp
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired, Email, Length
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json
import os

app = Flask(__name__, template_folder='app/templates', static_folder='app/static')
app.register_blueprint(routes_bp)

# Integrando com SQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:123Salsich%40#@localhost/ong'
# Secret Key
app.config['SECRET_KEY'] = "123Salsich@#"
# Inicializando o db'
db = SQLAlchemy(app)

def carregar_json(filename):
    try:
        with open(filename, "r", encoding="utf-8") as file:
                return json.load(file)
    except FileNotFoundError:
        print(f"Erro: O arquivo '{filename}' não foi encontrado.")
        return []
    except json.JSONDecodeError:
        print(f"Erro: O arquivo '{filename}' não é um JSON válido.")
        return []


    
@app.route("/usuarios/<int:user_id>")
def usuarios(user_id):
    usuarios = carregar_json("usuarios.json")
    # Encontrar usuario pelo id
    usuario_encontrado = next((u for u in usuarios if u['user_id'] == user_id), None)

    if usuario_encontrado is None:
        return abort(404) #retorna um 404 se o usuario nao for encontrado
    
    animais = carregar_json("animais.json")
    
    return render_template("usuarios/index.html", usuario = usuario_encontrado, animais = animais)

@app.route("/perfil_bicho/<nome_bicho>")
def perfil_bicho(nome_bicho):
    return render_template("perfil_bicho/index.html", nome_bicho=nome_bicho)

@app.route("/login")
def login():
    return render_template('login/login.html')

@app.route('/header')
def serve_header():
    return render_template('header/header.html') 

@app.route('/footer')
def serve_footer():
    return render_template('footer/footer.html')

#Invalid URL

@app.errorhandler(404)
def page_not_found(e):
    return render_template("erro/erro.html", erro = 404), 404

#Internal Server Error 

@app.errorhandler(500)
def page_not_found(e):
    return render_template("erro/erro.html", erro = 500), 500

if __name__ == "__main__":
    app.run(debug = True)